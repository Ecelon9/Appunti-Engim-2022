package com.engim.dbesempio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbEsempioApplicationTests {

    @Test
    void contextLoads() {
    }

}
