package com.engim.dbesempio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbEsempioApplication {

    public static void main(String[] args) {
        SpringApplication.run(DbEsempioApplication.class, args);
    }

}
