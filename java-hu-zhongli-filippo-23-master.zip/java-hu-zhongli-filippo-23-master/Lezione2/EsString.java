public class EsString {
    public static void main(String[] args) {
        String s = "Ciao";
        System.out.println(s.length());
//        String sub = s.substring(1, );
//        System.out.println(sub);
        /* Stampare tutte le lettere del nome tranne la prima */
        String s2 = "Ciao ".substring(0,4);
        System.out.println(5 == 5);
        System.out.println(s2);
        System.out.println(s == s2);
        
        System.out.println(s.equals(s2));
//        "ciao".equals("ciao");
        
    }
}
