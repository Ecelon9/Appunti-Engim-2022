package lezione5;
public class EsempioStack {
    public static int doppio(int n){
        return n*2;
    }
    public static int triplo(int n){
        return n*3;
    }
    public static void main(String[] args) {
        int a = 0;
        int b = 5;
        a = b - 1 ;
        a = doppio(a);
        int c = triplo(b);
        int[] d = new int[3];
    }

}
