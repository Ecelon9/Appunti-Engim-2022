package lezione5;

import util.Util;

import java.util.Scanner;

public class EsArray {

       /* metodo minimo -> restituisce il valore più piccolo
    metodo indiceMinimo -> restituisce l'indice del valore più piccolo
    *  metodo sommaVettoriale: dati due array a1 e a2, restituire a3
    *  che somma elemento per elemento
    *  ES: [1,2,3] e [2,3,4,5] : ritorno [3,5,7,5]
    * */

/*
    public static void main(String[] args) {
        int lunghezza = 5;
        int[] a = new int[lunghezza];
        a[0] = 1;
        a[1] = 4;
        System.out.println(a[0]);
        System.out.println(a.length);
        int[] b = {1,2,3,4,5};
        int[][] c = new int[3][3];
        c[0][0] = 2;
        int[][] d = {{1,2,3},{1,2,3}};
        for (int i = 0; i < a.length; i++){
           // a[i]
        }
        String[] stringhe = new String[4];


    }*/

    public static void main(String[] args) {
        int[] a = Util.crea(3);
    }
}
