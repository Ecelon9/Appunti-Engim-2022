package lezione5;

public class Esempio {
    public static void main(String[] args) {
        String s = "a";
        System.out.println("ciao".contains("ia"));
        System.out.println("AEIOUaeiou".contains(s));

    }
}
