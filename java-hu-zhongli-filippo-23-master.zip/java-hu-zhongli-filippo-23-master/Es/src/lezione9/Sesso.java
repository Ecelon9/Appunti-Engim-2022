package lezione9;

public enum Sesso {
    MASCHIO,FEMMINA,NON_BINARIO
}
