package lezione9;

public enum Materiale {
    PLASTICA,VETRO,METALLO
}
