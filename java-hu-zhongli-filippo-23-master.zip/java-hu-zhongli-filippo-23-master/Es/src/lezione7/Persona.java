package lezione7;

public class Persona {
}
