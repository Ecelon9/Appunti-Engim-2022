package lezione3;

public class OperatoreTernario {

    public static void main(String[] args) {
        int a = 1, b = 2;
//         CONDIZIONE ? VALORE SE VERO : VALORE SE FALSO
        int max = a < b ? b : a;

    }

}
