// 
public class HelloWorld{
    public static void main(String[] args){
        System.out.println("Hello world!");
        int a; // Dichiarazione di una variabile
        a = 10; // assegnamento
        int b = 5; // Dichiarazione e assegnamento
        System.out.println(a); 
        
    }
}
