public class Es1 {
    public static void main(String[] args) {
        double b = 0.1;
        int a = (int)b;
        char c = (char)97;
        System.out.println(a);
        System.out.println(c);
        
    }
    
}
