public class Selezione {
    public static void main(String[] args) {
        /* if
        if(CONDIZIONE){

        }
        // if-else
        if(CONDIZIONE){

        }else{

        }*/

        int a = 0;
        if(a == 0){
            System.out.println("OK");
        }

    }
}
