package com.engim.verificasimulazione;

public enum Ruolo {
    VILLICO, LUPO, VEGGENTE, MEDIUM, INDEMONIATO, PROTETTORE
}
