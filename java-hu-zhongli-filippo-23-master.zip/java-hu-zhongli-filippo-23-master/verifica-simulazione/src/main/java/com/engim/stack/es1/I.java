package com.engim.stack.es1;

public interface I {
    public boolean hasNext();
    public int getNum();
}
