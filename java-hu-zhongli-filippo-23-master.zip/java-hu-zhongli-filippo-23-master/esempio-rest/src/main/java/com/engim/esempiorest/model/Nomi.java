package com.engim.esempiorest.model;

import java.util.ArrayList;
import java.util.List;

public class Nomi {
    private static List<String> nomi = new ArrayList<>();

    public static List<String> getNomi() {
        return nomi;
    }

}
