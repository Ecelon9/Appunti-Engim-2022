package com.engim.esempiorest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsempioRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(EsempioRestApplication.class, args);
    }

}
