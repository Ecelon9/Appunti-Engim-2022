package com.engim.esempiospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsempioSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
