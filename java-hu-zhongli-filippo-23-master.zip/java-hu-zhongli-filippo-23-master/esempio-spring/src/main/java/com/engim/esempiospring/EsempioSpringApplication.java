package com.engim.esempiospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsempioSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(EsempioSpringApplication.class, args);
    }

}
