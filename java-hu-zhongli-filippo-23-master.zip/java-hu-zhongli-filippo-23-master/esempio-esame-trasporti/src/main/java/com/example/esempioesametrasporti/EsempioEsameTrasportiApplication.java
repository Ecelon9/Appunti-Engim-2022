package com.example.esempioesametrasporti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsempioEsameTrasportiApplication {

    public static void main(String[] args) {
        SpringApplication.run(EsempioEsameTrasportiApplication.class, args);
    }

}
