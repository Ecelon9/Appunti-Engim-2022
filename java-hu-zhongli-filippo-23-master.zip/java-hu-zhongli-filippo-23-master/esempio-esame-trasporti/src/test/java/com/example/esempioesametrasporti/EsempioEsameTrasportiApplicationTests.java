package com.example.esempioesametrasporti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsempioEsameTrasportiApplicationTests {

    @Test
    void contextLoads() {
    }

}
