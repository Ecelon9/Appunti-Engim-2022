<?php
// genero i link agli esercizi
echo '<a href="hello.php" target="_blank">Apri hello</a><br>';
echo "<hr>";
echo '<a href="conta.php" target="_blank">Apri conta</a><br>';
echo "<hr>";
echo '<form action="string.php" method="GET" target="_blank">';
echo '<input type="text" name="word" value="">';
echo '<input type="submit">';
echo '</form>';
echo "<hr>";
echo '<a href="form.php" target="_blank">Apri modulo</a><br>';
echo "<hr>";
echo '<a href="unalista.php" target="_blank">Apri lista</a><br>';