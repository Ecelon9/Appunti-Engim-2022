<?php

for($i=10 ; $i<= 90 ;$i++){
    echo $i . ' ';
}