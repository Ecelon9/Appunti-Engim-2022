<?php


// genero i link agli esercizi
echo '<a href="myhello.php" target="_blank">Apri myhello</a><br>';
echo "<hr>";
echo '<a href="conta.php" target="_blank">Apri conta</a><br>';
echo "<hr>";
echo '<form action="stampa.php" method="GET" target="_blank">';
echo '<input type="text" name="text" value="">';
echo '<input type="submit">';
echo '</form>';
echo "<hr>";
echo '<a href="modulo.php" target="_blank">Apri modulo</a><br>';
echo "<hr>";
echo '<a href="mialista.php" target="_blank">Apri lista</a><br>';